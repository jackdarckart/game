const form = document.querySelector('#authForm');
const handleInput = document.querySelector('#handle');
const passwordInput = document.querySelector('#password');
const submitButton = document.querySelector('#submitButton');
const message = document.querySelector('#message');
const loginTab = document.querySelector('#loginTab');
const registerTab = document.querySelector('#registerTab');
let mode = 'login';

function showMessage(text, type = 'error') {
  message.textContent = text;
  message.className = `mt-5 rounded-lg border px-4 py-3 text-sm ${type === 'success' ? 'border-emerald-400/40 bg-emerald-400/10 text-emerald-200' : 'border-red-400/40 bg-red-400/10 text-red-200'}`;
}

function setMode(nextMode) {
  mode = nextMode;
  const login = mode === 'login';
  loginTab.className = login
    ? 'flex-1 rounded-lg px-4 py-3 bg-cyan-500/20 border border-cyan-400/40 text-cyan-200'
    : 'flex-1 rounded-lg px-4 py-3 bg-slate-900 border border-slate-700 text-slate-400';
  registerTab.className = !login
    ? 'flex-1 rounded-lg px-4 py-3 bg-cyan-500/20 border border-cyan-400/40 text-cyan-200'
    : 'flex-1 rounded-lg px-4 py-3 bg-slate-900 border border-slate-700 text-slate-400';
  submitButton.textContent = login ? 'VAULT ÖFFNEN' : 'ACCOUNT ERSTELLEN';
  passwordInput.autocomplete = login ? 'current-password' : 'new-password';
  message.classList.add('hidden');
}

loginTab.addEventListener('click', () => setMode('login'));
registerTab.addEventListener('click', () => setMode('register'));

async function checkSession() {
  const response = await fetch('/api/session', { credentials: 'same-origin', cache: 'no-store' });
  if (!response.ok) return;
  const data = await response.json();
  if (data.authenticated) window.location.replace('/game.html');
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  submitButton.disabled = true;
  message.classList.add('hidden');
  try {
    const response = await fetch(mode === 'login' ? '/api/login' : '/api/register', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ handle: handleInput.value.trim(), password: passwordInput.value })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Anmeldung fehlgeschlagen.');
    showMessage('Vault geöffnet. Weiter zum Spiel …', 'success');
    window.setTimeout(() => window.location.replace('/game.html'), 250);
  } catch (error) {
    showMessage(error.message || 'Anmeldung fehlgeschlagen.');
  } finally {
    submitButton.disabled = false;
  }
});

checkSession().catch(() => {});
